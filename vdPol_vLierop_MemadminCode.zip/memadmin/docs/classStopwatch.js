var classStopwatch =
[
    [ "Stopwatch", "classStopwatch.html#a628b5ebeed5df065dd847e68fb6336cf", null ],
    [ "gettotal", "classStopwatch.html#a98a46a8603f4fd4547b483c45b7eb197", null ],
    [ "report", "classStopwatch.html#aa5977fc4a8ede47878790ff6d2cf569d", null ],
    [ "reset", "classStopwatch.html#a42c7014e7fffcf4c56ca6fb07f8eb31c", null ],
    [ "start", "classStopwatch.html#a6d01ecc80c92f1d5210cd9c3eb72883d", null ],
    [ "stop", "classStopwatch.html#aa0266311b7392b948061bb985b49cff4", null ]
];