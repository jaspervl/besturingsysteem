var classArea_1_1orderBySizeDescending =
[
    [ "operator()", "classArea_1_1orderBySizeDescending.html#af865d022d45cd31556ce8671e5c47f04", null ]
];