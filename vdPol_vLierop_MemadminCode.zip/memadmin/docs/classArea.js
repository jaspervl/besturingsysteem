var classArea =
[
    [ "orderByAddress", "classArea_1_1orderByAddress.html", "classArea_1_1orderByAddress" ],
    [ "orderBySizeAscending", "classArea_1_1orderBySizeAscending.html", "classArea_1_1orderBySizeAscending" ],
    [ "orderBySizeDescending", "classArea_1_1orderBySizeDescending.html", "classArea_1_1orderBySizeDescending" ],
    [ "Area", "classArea.html#a18d88076b96b8447af329953c82f85b9", null ],
    [ "getBase", "classArea.html#a6b095d60b051a2e6eaad6e595ff64d79", null ],
    [ "getLast", "classArea.html#afe6c2fb82b49124ce63d25c64b4441b9", null ],
    [ "getSize", "classArea.html#ae73461a81ee3d92546ae38598afdb0c4", null ],
    [ "join", "classArea.html#a09628d6fefec11182922506da990a1ae", null ],
    [ "overlaps", "classArea.html#a36c4256e4e12bea8bc9700f3af7bb2af", null ],
    [ "split", "classArea.html#aad29708feb18c2991e79c419d64da389", null ],
    [ "operator<<", "classArea.html#ad40b0ff3723b7da62c3da9071c980cd5", null ]
];