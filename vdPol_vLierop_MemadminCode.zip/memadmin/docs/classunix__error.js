var classunix__error =
[
    [ "unix_error", "classunix__error.html#aa4b2cc489b5b8f0ee5eb41869b473c89", null ],
    [ "unix_error", "classunix__error.html#af137acb46bd7e4b7f9471ecec8131f60", null ],
    [ "unix_error", "classunix__error.html#a4fcf8a71756c1b024625aa82165de3f4", null ],
    [ "unix_error", "classunix__error.html#acf795d52869878610f4a11ae0b34c0a9", null ],
    [ "unix_error", "classunix__error.html#a190bec10c7dc138c1c5e14509b0b021e", null ],
    [ "code", "classunix__error.html#a9d7221622930d3b4e00085afaafa4b78", null ]
];