var Stopwatch_8h =
[
    [ "Stopwatch", "classStopwatch.html", "classStopwatch" ],
    [ "S_CLOCK", "Stopwatch_8h.html#a11aee89e57ce75fd2084050f5f705757", null ],
    [ "S_GPT32", "Stopwatch_8h.html#a4b3ae370cd0cb27c4f2e90dc5e1276b1", null ],
    [ "S_RUSAGE", "Stopwatch_8h.html#a942fd2dbc3d2ae375282fbaaa78ee31f", null ],
    [ "S_TIME", "Stopwatch_8h.html#aa092233cbf5fdea76c7eb400de0522e3", null ],
    [ "S_TIMES", "Stopwatch_8h.html#aaac8b08f06dfc11b5badfb15105eeb84", null ]
];