var searchData=
[
  ['nextfit',['NextFit',['../classNextFit.html#a51b5c8268b01baaae047c1582865b961',1,'NextFit']]],
  ['nextfit2',['NextFit2',['../classNextFit2.html#ad91161d338cc9a9d4f4222f37fef6e4a',1,'NextFit2']]]
];
