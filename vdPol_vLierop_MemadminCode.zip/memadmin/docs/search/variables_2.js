var searchData=
[
  ['cflag',['cflag',['../classAllocator.html#a9d5d07af8e2e54deb7a8863f629fb1d8',1,'Allocator::cflag()'],['../main_8cc.html#a822b55fa4382fe95952731213f4be5f7',1,'cflag():&#160;main.cc']]],
  ['cursor',['cursor',['../classNextFit.html#a4c32e9dc659219ddf3ee1bd119617606',1,'NextFit']]]
];
