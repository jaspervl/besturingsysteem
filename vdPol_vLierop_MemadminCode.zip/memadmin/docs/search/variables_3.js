var searchData=
[
  ['mergers',['mergers',['../classFitter.html#a151741292950ebd171ea81f1953e118a',1,'Fitter']]]
];
