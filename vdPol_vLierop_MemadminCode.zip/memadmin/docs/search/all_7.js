var searchData=
[
  ['getbase',['getBase',['../classArea.html#a6b095d60b051a2e6eaad6e595ff64d79',1,'Area']]],
  ['getlast',['getLast',['../classArea.html#afe6c2fb82b49124ce63d25c64b4441b9',1,'Area']]],
  ['getsize',['getSize',['../classAllocator.html#a1c67381777b1b43a4f237f9045b875cf',1,'Allocator::getSize()'],['../classArea.html#ae73461a81ee3d92546ae38598afdb0c4',1,'Area::getSize()']]],
  ['gettotal',['gettotal',['../classStopwatch.html#a98a46a8603f4fd4547b483c45b7eb197',1,'Stopwatch']]],
  ['gettype',['getType',['../classAllocator.html#aab1d481ff3438ee226e09e20da8130b7',1,'Allocator']]]
];
