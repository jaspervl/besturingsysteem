var classFitter =
[
    [ "Fitter", "classFitter.html#a68620f65ecf0d32427030ae087bf1d72", null ],
    [ "alloc", "classFitter.html#a4efd7fec6488aa0e91866715e1ebe53b", null ],
    [ "free", "classFitter.html#aaab40dae6e0206c757c5f5bbff01d54d", null ],
    [ "getSize", "classFitter.html#a1c67381777b1b43a4f237f9045b875cf", null ],
    [ "getType", "classFitter.html#aab1d481ff3438ee226e09e20da8130b7", null ],
    [ "reclaim", "classFitter.html#ac8ffb3a3e66ff4a6f074106f16014235", null ],
    [ "report", "classFitter.html#ae9cc31ac2ac3c6e3a0043f8ee77de937", null ],
    [ "searcher", "classFitter.html#af9a2537b0bd8e9ed09703d783b83eaf9", null ],
    [ "setCheck", "classFitter.html#a3bf70e649198f0cf39c54c7c55078681", null ],
    [ "setSize", "classFitter.html#acd0b2bf681496daad637ac0b024eafd8", null ],
    [ "cflag", "classFitter.html#a9d5d07af8e2e54deb7a8863f629fb1d8", null ],
    [ "mergers", "classFitter.html#a151741292950ebd171ea81f1953e118a", null ],
    [ "qcnt", "classFitter.html#a31dd0a74283e3a6b182a7940ae654c11", null ],
    [ "qsum", "classFitter.html#a5a632aab749445ef4f366e2ebac01e85", null ],
    [ "qsum2", "classFitter.html#a47fbb29535d6b46c8bbbd4db243d2579", null ],
    [ "reclaims", "classFitter.html#a9377ebc83e806d89983d5507005f7913", null ],
    [ "size", "classFitter.html#a5d7a71270a7820aa97ebd17794ce8771", null ],
    [ "type", "classFitter.html#a8c31faaa57658964ac597567b10c9983", null ]
];