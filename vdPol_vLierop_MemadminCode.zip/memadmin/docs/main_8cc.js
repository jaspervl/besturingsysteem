var main_8cc =
[
    [ "doOptions", "main_8cc.html#a40b7218b9d4c4611a1757fded36a799a", null ],
    [ "main", "main_8cc.html#a0ddf1224851353fc92bfbff6f499fa97", null ],
    [ "tellOptions", "main_8cc.html#aeae828dc4cbaf64dfc48be2bfa2b1cc6", null ],
    [ "aantal", "main_8cc.html#a8cfb518d914f91e754103a30b4379389", null ],
    [ "beheerders", "main_8cc.html#aeb4662d78c799357c7682c97ef7e93f6", null ],
    [ "cflag", "main_8cc.html#a822b55fa4382fe95952731213f4be5f7", null ],
    [ "size", "main_8cc.html#a439227feff9d7f55384e8780cfc2eb82", null ],
    [ "tflag", "main_8cc.html#a902e2d2a5f4f5ea9be412316bf43c5a3", null ],
    [ "vflag", "main_8cc.html#ac710816f73e3cefff5011aab1bc9a796", null ]
];