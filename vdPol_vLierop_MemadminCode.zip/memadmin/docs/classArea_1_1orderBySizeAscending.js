var classArea_1_1orderBySizeAscending =
[
    [ "operator()", "classArea_1_1orderBySizeAscending.html#ae560a2517b217e4f39b0944e090cf4b4", null ]
];